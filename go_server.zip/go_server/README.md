# Go Server Dockerization

This document provides instructions for containerizing and running the Go server application using Docker, based on the provided Dockerfile.

## Explanation and Usage
Single-Stage Build: This approach results in a larger image size as it includes both the build environment and all artifacts. It's simpler but less efficient in terms of the final image size and unnecessary content. - 511MB

## Multi-Stage Build: 
This is more efficient as it reduces the final image size by excluding the build environment and intermediate artifacts, only including what is necessary to run the application. This is typically preferred for production environments. - 15.4MB


## Prerequisites

- Docker installed on your system.
- Make sure project build successfully local env

## Building the Docker Image

To containerize the Go server application, follow these steps to build the Docker image:

1. Open a terminal and navigate to the directory containing the Dockerfile.
2. Build the Docker image using the following command:

```bash
docker build -t go-server:1.0 .
```
2. To make sure docker image sucessfully using the following command:
```bash
docker images
```

This command creates a Docker image named `go-server` with the tag `1.0`.

## Running the Container

After building the image, you can run the Go server in a Docker container:

1. To run the container, use the following command:

```bash
docker run -d -p 8181:8181 --name go-server-instance go-server:1.0
```

    This command runs the container in detached mode, maps port 8181 of the container to port 8181 on the host, and names the container instance `go-server-instance`.

## Verify that the container is running successfully using the following command:
```bash
docker ps
```
To check all running containers, use the following command:
```bash
docker ps -a
```


## Verifying the Server is Running
```bash
docker container logs go-server-instance
```
## containers run time log check using following command:
```bash
docker container logs -f go-server-instance
```

To check if the Go server is running correctly inside the Docker container:

1. Open a web browser and navigate to `http://localhost:8080`. You should see "Hello, from Ostad! <3".
2. To check the health of the application, go to `http://localhost:8080/health`. You should see `{"Status": "OK"}`.

## Stopping the Container

When you are done, you can stop the running container using the following command:

```bash
docker stop go-server-instance
```
And if you wish to remove the container:

```bash
docker rm go-server-instance
```

## Additional Notes

- The application listens on port 8080 by default, as specified in the Dockerfile. If you wish to use a different port, adjust the `-p` argument in the `docker run` command accordingly.